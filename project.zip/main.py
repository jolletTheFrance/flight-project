if __name__ == "__main__":
    from flask import Flask, request, render_template, url_for, redirect
    import functions
    import sqlite3
    import json
    import functions
    import logging

    app = Flask(__name__)

    logging.basicConfig(filename='worklog.log', level=logging.DEBUG,format='%(asctime)s: --- %(levelname)s --- line:%(lineno)d--- funcName:	%(funcName)s ||| %(message)s |||')

    # each class contains same attributes as in the DB

    class User:
        def __init__(self, userid, name, password, realID):
            self.userid = userid
            self.name = name
            self.password = password
            self.realID = realID


    class Tickets:
        def __init__(self, ticketID, userID, flightID):
            self.ticketID = ticketID
            self.userID = userID
            self.flightID = flightID


    class Flights:
        def __init__(self, flightID, timestamp, remaining_seats, originCountryID, destCountryID):
            self.flightID = flightID
            self.timestamp = timestamp
            self.remaining_seats = remaining_seats
            self.originCountryID = originCountryID
            self.destCountryID = destCountryID


    class Countries:
        def __init__(self, codeAI, name):
            self.codeAI = codeAI
            self.name = name


    @app.route("/")
    def homepage(name=None, id=None):
        logging.debug("a user requested the main page")
        return render_template("hello.html", name=name, id=id)


    @app.route("/manu")
    def manu(name=None, id=None):
        '''
        just greets the user and gives them a manu
        :param name: name of user
        :param id: id of user
        :return:
        '''
        logging.debug(f"manu page requested with id {id}")
        if name == None:
            return "please log in first"
            logging.debug(f"manu page requested with no id!")
        return render_template("hello_name.html", name=name, id=id)


    @app.route("/userflight/<int:id>", methods=["POST", "GET"])
    def userflight(id):
        '''
        gets all tickets a user has
        :param id: id of user
        :return: list of all tickets in html
        '''
        logging.info(f"user id = {id} requested his ticket page!")
        # if id == None:
        #   return "please login first"
        conn, command = functions.startDB()
        command = conn.execute(f"SELECT * from tickets WHERE user_id = {id}")
        answer = command.fetchall()
        if len(answer) > 0:
            ticketList = []
            for ticket in answer:
                thisTicket = Tickets(ticket[0], ticket[1], ticket[2])
                thisTicket = thisTicket.__dict__
                ticketList.append(dict(thisTicket))
            functions.closeDB(conn)
            return render_template("mytickets.html", ticketlist=ticketList)

        else:
            functions.closeDB(conn)
            logging.debug(f"user id ={id} requested ticket page but no tickets found!")
            return render_template("tomain.html", info="user has no tickets")


    @app.route("/buyticket/<id>")
    def userticket(id):
        '''
        :param id: id of the ticket to buy
        :return: return template of available flights
        '''
        conn, command = functions.startDB()
        flightlist = getflight(givelist=1)
        logging.debug(f"user id = {id} asked to see available flights")
        for flight in flightlist:
            flight["originCountryID"] = functions.getcountryname(flight["originCountryID"])
            flight["destCountryID"] = functions.getcountryname(flight["destCountryID"])
            # print(flight["destCountryID"])
        return render_template("buyticket.html", flightlist=flightlist, id=id)

# all get post delete and put functions are pretty much the same
    @app.route("/getuser")
    @app.route("/getuser/<int:id>")
    def getuser(id=None):
        '''
        gets all users and creates a list of them or get only one by ID
        :param id: id of the user to ger (not required)
        :return: template with all users
        '''
        conn, command = functions.startDB()

        if id == None:
            logging.debug(f"a user requested to see all users")
            command = conn.execute("select * from users")
            userList = []
            for user in command:
                thisUser = User(user[0], user[1], user[2], user[3])
                thisUser = thisUser.__dict__
                userList.append(thisUser)
            return render_template("showuser.html", userlist=userList)
        else:
            logging.debug(f"a user requested to see user id = {id}")
            command = conn.execute(f"SELECT * from users WHERE id = {id}")
            if len(list(command)) > 0:
                command = conn.execute(f"SELECT * from users WHERE id = {id}")
                userList = []
                # check why this query is needed
                for user in command:
                    thisUser = User(user[0], user[1], user[2], user[3])
                    thisUser = thisUser.__dict__
                    userList.append(thisUser)
                return render_template("showuser.html", userlist=userList)

            else:
                logging.debug(f"a user requested to see user id = {id} but no such user found")
                return render_template("tomain.html", info="no such user")


    @app.route("/postuser", methods=["POST", "GET"])
    def postuser():
        '''
        :return: gets info from HTML and if username is taken or creates an account
        '''

        if request.method == "GET":
            logging.debug(f"a user requested to see post user page")
            return render_template('postuser.html')

        elif request.method == "POST":
            logging.debug(f"a user requested to see post a new user")

            full_name = request.form['full_name']
            password = request.form['password']
            real_id = request.form['real_id']

            userList = getusers()
            for user in userList:
                if user["name"] == full_name or user["realID"] == real_id:
                    logging.debug(f"a user requested to see post a new user but username was taken!")
                    return render_template("tomain.html", info="username taken")


            else:
                conn, command = functions.startDB()
                command = conn.execute(
                    f"insert into users(full_name, password , real_id) VALUES (\"{full_name}\", {password}, {real_id})")
                functions.closeCommitDB(conn, command)
                return render_template("tomain.html", info="username created")


    @app.route("/updateuser/<int:id>", methods=["put"])
    def updateUser(id):
        '''
        updates info of users
        :param id: id of the user
        :return: just a string
        '''
        logging.debug(f"a user requested to update a user!")
        conn, command = functions.startDB()
        command.execute(f"select * from users where id = {id}")
        for row in command:
            olduser = User(row[0], row[1], row[2], row[3])
        newuser = request.json
        newuser = json.dumps(newuser)
        newuser = json.loads(newuser)

        if olduser.name != newuser["name"]:
            olduser.name = newuser["name"]
            command.execute(f"UPDATE users SET full_name = \"{olduser.name}\" WHERE id = {id}")
            logging.debug(f"a user requested to update a username from {olduser.name} to {newuser['name']}!")

        if olduser.password != newuser["password"]:
            olduser.password = newuser["password"]
            command.execute(f"UPDATE users SET password = {olduser.password} WHERE id = {id}")
            logging.debug(f"a user requested to update a password from {olduser.password} to {newuser['password']}!")

        if olduser.realID != newuser["realID"]:
            olduser.realID = newuser["realID"]
            command.execute(f"UPDATE users SET real_id = {olduser.realID} WHERE id = {id}")
            logging.debug(f"a user requested to update real id from {olduser.realID} to {newuser['realID']}!")

        command.execute(f"UPDATE flights SET timestamp = datetime() WHERE flightID = {id}")
        logging.debug(f"time stamp of flight id = {id} was updated!")
        functions.closeCommitDB(conn, command)
        return render_template("tomain.html", info=f"user updated! --> {olduser.__dict__}")

    @app.route("/deleteuser/<int:id>", methods=["delete"])
    def deleteUser(id):
        '''
        deletes user by id
        :param id: id of the user
        :return: same, just a string
        '''
        logging.debug(f"a user requested to delete user id = {id}!")
        conn, command = functions.startDB()
        command.execute(f"DELETE FROM users WHERE id = {id}")
        functions.closeCommitDB(conn, command)
        logging.info(f"user id = {id} was deleted from DB!")
        return render_template("tomain.html", info=f"user ID={id} was removed")

    @app.route("/getflight")
    @app.route("/getflight/<int:id>")
    def getflight(id=None, givelist=0):
        conn, command = functions.startDB()
        if id == None:
            logging.debug(f"a user requested to see all flights!")
            command = conn.execute("select * from flights")
            flightList = []
            for flight in command:
                thisFlight = Flights(flight[0], flight[1], flight[2], flight[3], flight[4])
                thisFlight = thisFlight.__dict__
                flightList.append(thisFlight)
            if givelist == 1:
                return flightList
            return render_template("showflight.html", flightlist=flightList)

        else:
            logging.debug(f"a user requested to see flight id = {id}!")
            command = conn.execute(f"SELECT * from flights WHERE flight_id = {int(id)}")
            answer = command.fetchall()
            print(answer)
            if len(list(answer)) > 0:
                flightList = []
                for flight in answer:
                    thisFlight = Flights(flight[0], flight[1], flight[2], flight[3], flight[4])
                    thisFlight = thisFlight.__dict__
                    flightList.append(thisFlight)
                functions.closeDB(conn)
                return render_template("showflight.html", flightlist=flightList)

            else:
                functions.closeDB(conn)
                logging.debug(f"a user requested to see flight id = {id}! but there is no such flight")
                return render_template("tomain.html", info="no such flight")

    @app.route("/postflight", methods=["POST", "GET"])
    def postflight():

        if request.method == "GET":
            logging.debug(f"a user requested to post flight page")
            return render_template('postflight.html')

        elif request.method == "POST":
            logging.debug(f"a user requested to post a new flight")

            seats = request.form['seatsleft']
            origin = request.form['origionCountryId']
            dest = request.form['destCountryId']

            conn, command = functions.startDB()
            command = conn.execute(
                f"insert into flights(timestamp, remaining_seats , origin_country_id, dest_country_id) VALUES (datetime(), {seats}, {origin}, {dest})")
            functions.closeCommitDB(conn, command)
            logging.info(f"a new flight was added")
            return render_template("tomain.html", info="flight added")

    @app.route("/updateflight/<int:id>", methods=["put"])
    def updateflight(id):
        logging.debug(f"a user requested to update flight details of flight id = {id}")
        conn, command = functions.startDB()
        command.execute(f"select * from flights where flight_id = {id}")
        for row in command:
            oldflight = Flights(row[0], row[1], row[2], row[3], row[4])
        newflight = request.json
        newflight = json.dumps(newflight)
        newflight = json.loads(newflight)

        if oldflight.originCountryID != newflight["originCountryID"]:
            logging.info(f"a user requested to update flight origin of flight id = {id} from {oldflight.originCountryID} to {newflight['originCountryID']}")
            oldflight.originCountryID = newflight["originCountryID"]
            command.execute(f"UPDATE flights SET origin_country_id = {oldflight.originCountryID} WHERE flight_id = {id}")

        if oldflight.destCountryID != newflight["destCountryID"]:
            logging.info(f"a user requested to update flight dest of flight id = {id} from {oldflight.destCountryID} to {newflight['destCountryID']}")
            oldflight.destCountryID = newflight["destCountryID"]
            command.execute(f"UPDATE flights SET dest_country_id = {oldflight.destCountryID} WHERE flight_id = {id}")

        if oldflight.remaining_seats != newflight["remaining_seats"]:
            logging.info(f"a user requested to update flight dest of flight id = {id} from {oldflight.remaining_seats} to {newflight['remaining_seats']}")
            oldflight.remaining_seats = newflight["remaining_seats"]
            command.execute(f"UPDATE flights SET remaining_seats = {oldflight.remaining_seats} WHERE flightID = {id}")

        command.execute(f"UPDATE flights SET timestamp = datetime() WHERE flightID = {id}")
        logging.info(f"time stamp of flight id = {id} was updated")
        functions.closeCommitDB(conn, command)
        return render_template("tomain.html", info=f"flight updated! --> {oldflight.__dict__}")

    @app.route("/deleteflight/<int:id>", methods=["delete"])
    def deleteflight(id):
        conn, command = functions.startDB()
        logging.debug(f"a user requested to delete flight id = {id} from DB")
        command.execute(f"DELETE FROM flights WHERE flightID = {id}")
        logging.info(f"a user requested to delete flight id = {id} was removed from DB")
        functions.closeCommitDB(conn, command)
        return render_template("tomain.html", info=f"flight ID={id} was removed")

    @app.route("/getticket")
    @app.route("/getticket/<int:id>")
    def getticket(id=None):
        conn, command = functions.startDB()

        if id == None:
            logging.debug(f"a user requested to see all tickets")
            command = conn.execute("select * from tickets")
            ticketList = []
            for ticket in command:
                thisticket = Tickets(ticket[0], ticket[1], ticket[2])
                thisticket = thisticket.__dict__
                ticketList.append(dict(thisticket))
            print(ticketList[0]["ticketID"])
            return render_template("showtickets.html", ticketlist=ticketList)
        else:
            logging.debug(f"a user requested to see ticket id = {id}")
            command = conn.execute(f"SELECT * from tickets WHERE ticket_id = {id}")
            if len(list(command)) > 0:
                command = conn.execute(f"SELECT * from tickets WHERE ticket_id = {id}")
                # check why this query is needed
                ticketList = []
                for ticket in command:
                    thisTicket = Tickets(ticket[0], ticket[1], ticket[2])
                    thisTicket = thisTicket.__dict__
                    ticketList.append(dict(thisTicket))
                functions.closeDB(conn)
                return render_template("showtickets.html", ticketlist=ticketList)

            else:
                functions.closeDB(conn)
                logging.debug(f"a user requested to see ticket id = {id} but no such ticket")
                return render_template("tomain.html", info=f"no such ticket")

    @app.route("/postticket/<int:id>", methods=["GET"])
    @app.route("/postticket", methods=["POST", "GET"])
    def postticket(id=""):

        if request.method == "GET":
            logging.debug(f"a user requested post ticket page!")
            return render_template('postticket.html', id=id)

        elif request.method == "POST":
            user_id = request.form["user_id"]
            flight_id = request.form["flight_id"]
            logging.info(f"a user requested post post a new ticket for user id = {user_id}!")

            conn, command = functions.startDB()
            command = conn.execute(f"select id from users where id = {user_id}")
            temp = command.fetchall()
            for seat in temp:
                temp = seat[0]

            if isinstance(temp, list):
                return render_template("tomain.html", info=f"wrong user id")
            logging.info(f"a user requested post post a new ticket for user id = {user_id} but no such user was found!")

            command = conn.execute(f"insert into tickets(user_id, flight_id) VALUES ({user_id}, {flight_id})")

            command = conn.execute(
                f"select ticket_id from tickets where user_id = {user_id} and flight_id = {flight_id}")

            ticketid = command.fetchall()
            for ticket in ticketid:
                ticketid = ticket[0]

            command = conn.execute(f"select remaining_seats from flights WHERE flight_id = (SELECT flight_id from tickets WHERE ticket_id = {ticketid})")
            temp = command.fetchall()

            for seat in temp:
                temp = seat[0]

            if isinstance(temp, int) and temp < 1:
                logging.info(f"a user requested post post a new ticket for user id = {user_id} but no tickets left!")
                return render_template("tomain.html", info=f"no seats left!")


            command = conn.execute(
                f"UPDATE flights set remaining_seats =(select remaining_seats from flights WHERE flight_id\n"
                f" = (SELECT flight_id from tickets WHERE ticket_id = {ticketid} ))\n"
                f" -1 WHERE flight_id = {flight_id}")

            functions.closeCommitDB(conn, command)
            logging.info(f"ammound of seats was lowered!")
            return render_template("tomain.html", info=f"ticket added")

    #@app.route("/updateticket/<int:id>", methods=["put"])
    #def updateticket(id):
    #    conn, command = functions.startDB()
    #    command.execute(f"select * from tickets where ticket_id = {id}")
    #    for row in command:
    #        oldticket = Tickets(row[0], row[1], row[2])
    #    newticket = request.json
    #    newticket = json.dumps(newticket)
    #    newticket = json.loads(newticket)
#
    #    if oldticket.userID != newticket["user_id"]:
    #        oldticket.userID = newticket["user_id"]
    #        command.execute(f"UPDATE tickets SET user_id = {oldticket.userID} WHERE ticket_id = {id}")
#
    #    if oldticket.flightID != newticket["flight_id"]:
    #        oldticket.flightID = newticket["flight_id"]
    #        command.execute(f"UPDATE tickets SET flight_id = {oldticket.flightID} WHERE ticket_id = {id}")
#
    #    functions.closeCommitDB(conn, command)
    #    return render_template("tomain.html", info=f"ticket updated! --> {oldticket.__dict__}")

    @app.route("/deleteticket/<int:id>", methods=["delete", "get"])
    def deleteticket(id):
        logging.debug(f"a user requested to delete ticket id = {id}")
        conn, command = functions.startDB()
        command.execute(f"DELETE FROM tickets WHERE ticket_id = {id}")
        functions.closeCommitDB(conn, command)
        logging.info(f"ticket id = {id} was removed")
        return render_template("tomain.html", info=f"ticket ID={id} was removed")

    @app.route("/getcountry")
    @app.route("/getcountry/<int:id>")
    def getcountry(id=None):
        conn, command = functions.startDB()

        if id == None:
            logging.debug(f"a user requested to see all countries")
            command = conn.execute("select * from countries")
            countryList = []
            for country in command:
                thiscountry = Countries(country[0], country[1])
                thiscountry = thiscountry.__dict__
                countryList.append(thiscountry)
            return render_template("showcountry.html", countrylist=countryList)
        else:
            logging.debug(f"a user requested to see country id = {id}")
            command = conn.execute(f"SELECT * from countries WHERE code_ai = {id}")
            if len(list(command)) > 0:
                command = conn.execute(f"SELECT * from countries WHERE code_ai = {id}")
                countryList = []
                # check why this query is needed
                for country in command:
                    thiscountry = Countries(country[0], country[1])
                    thiscountry = thiscountry.__dict__
                    countryList.append(thiscountry)
                functions.closeDB(conn)
                return render_template("showcountry.html", countrylist=countryList)

            else:
                functions.closeDB(conn)
                logging.info(f"a user requested to see country id = {id} but no such country was found")
                return render_template("tomain.html", info="no such country")

    @app.route("/postcountry", methods=["POST", "GET"])
    def postcountry():
        if request.method == "GET":
            logging.debug(f"a user requested to see post country page")
            return render_template('postcountry.html')

        elif request.method == "POST":

            name = request.form['name']
            logging.debug(f"a user requested to add {name} to countries list")

            conn, command = functions.startDB()
            command = conn.execute(f"insert into countries(name) VALUES (\"{name}\")")
            functions.closeCommitDB(conn, command)
            logging.info(f"{name} was added to countries list")
            return render_template("tomain.html", info="country added")

    @app.route("/updatecountry/<int:id>", methods=["put"])
    def updatecountry(id):
        logging.debug(f"a user requested to update country id = {id}")
        conn, command = functions.startDB()
        command.execute(f"select * from countries where code_ai = {id}")
        for row in command:
            oldcountry = Countries(row[0], row[1])
        newcountry = request.json
        newcountry = json.dumps(newcountry)
        newcountry = json.loads(newcountry)

        if oldcountry.name != newcountry["name"]:
            logging.debug(f"a user requested to update country (id = {id}) name from {oldcountry.name} to {newcountry['name']}")
            oldcountry.name = newcountry["name"]
            command.execute(f"UPDATE countries SET name = \"{oldcountry.name}\" WHERE code_ai = {id}")
            logging.info(f"country (id = {id}) name was changed from {oldcountry.name} to {newcountry['name']}")

        functions.closeCommitDB(conn, command)
        return render_template("tomain.html", info=f"country updated! --> {oldcountry.__dict__}")

    @app.route("/deletecountry/<int:id>", methods=["delete"])
    def deletecountry(id):
        logging.debug(f"a user requested to delete country (id = {id})")
        conn, command = functions.startDB()
        command.execute(f"DELETE FROM countries WHERE code_ai = {id}")
        functions.closeCommitDB(conn, command)
        logging.info(f"country (id = {id}) was deleted from countries list")
        return render_template("tomain.html", info=f"country ID={id} was removed")



    def getusers():
        '''
        :return: returns all users in a list of objects of user class
        '''
        logging.debug(f"list of all users was requested")
        conn, command = functions.startDB()
        command = conn.execute("select * from users")
        userList = []
        for user in command:
            thisUser = User(user[0], user[1], user[2], user[3])
            userList.append(thisUser.__dict__)
        functions.closeDB(conn)
        return userList


    # login and sign-up
    @app.route("/login", methods=["GET", "POST"])
    def login():
        '''
        :return: redirect to personal manu
        search for user from all users then get password and test it
        '''
        if request.method == "GET":
            return render_template("login.html")
        elif request.method == "POST":
            username = request.form['username']
            password = request.form['password']
            userlist = list(getusers())
            for user in userlist:
                if username == user["name"]:

                    if password == user["password"]:
                        logging.info(f"user {username} loged in with password {password}")
                        personal = manu(name=user["name"], id=int(user["userid"]))
                        return personal
                    else:
                        logging.debug(f"user {username} tried to login but password {password} is wrong")
                        return render_template("tomain.html", info="wrong password")

            else:
                logging.debug(f"user {username} tried to login but no such user name found in DB")
                return render_template("tomain.html", info="wrong username")


    @app.route("/signup", methods=["GET", "POST"])
    def signup():
        '''
        just returns the user to /postuser template
        :return: postuser template
        '''
        if request.method == "GET":
            return render_template("postuser.html")


    app.run()
